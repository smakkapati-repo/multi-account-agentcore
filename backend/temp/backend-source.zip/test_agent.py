"""Minimal test agent to debug the issue"""
from bedrock_agentcore import BedrockAgentCoreApp

app = BedrockAgentCoreApp()

@app.entrypoint
def invoke(payload):
    """Simple entrypoint that just returns a greeting"""
    return "Hello from BankIQ+ test agent!"

if __name__ == "__main__":
    app.run()