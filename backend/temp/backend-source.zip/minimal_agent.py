"""Minimal working agent to test container startup"""
from bedrock_agentcore import BedrockAgentCoreApp

app = BedrockAgentCoreApp()

@app.entrypoint
def invoke(payload):
    return "Hello from minimal agent!"

if __name__ == "__main__":
    app.run()